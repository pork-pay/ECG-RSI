# ECG-RSI arXiv long-form manuscript

Based on the latest ICLR manuscript, expanded for an arXiv/preprint presentation in the original medreflect template. The ICLR source directory is unchanged.

Overleaf: upload ECG_RSI_arXiv.zip, select main.tex, compiler pdfLaTeX, recent TeX Live.
For arXiv source submission, use the same source files and main.bbl; main.pdf is the compiled preview. No special arXiv document class is required.

Promoted to the main text: feedback heatmap and difficulty statistics; complete clinical expert review; five-model question-quality analysis; synthesis-update and evolution-strategy visualization. Added discussion connects the distinct evidence streams.
Detailed category/branch records, the separately reported multi-seed results, construction protocols, prompts, and full case responses remain supplementary.
